﻿public struct GMapsLocation
{
    public decimal Lat { get; set; }
    public decimal Lng { get; set; }
}