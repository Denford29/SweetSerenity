{
	"geoCodeError":"Oops! Probleempje met het valideren van het adres! Probeer nogmaals.",
	"locationSet":"Locatie gewijzigd naar: ",
	"resetTxt":"Beginsituatie terugzetten"
}